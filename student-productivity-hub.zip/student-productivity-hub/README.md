# Student Productivity Hub

A modern, responsive productivity dashboard for students built with **HTML, CSS, and JavaScript**.

## Features
- Task Manager (add / edit / delete / complete)
- Pomodoro Timer (start / pause / reset + settings)
- CGPA Calculator (multiple subjects + credits)
- Notes (save / delete)
- Goal Tracker (progress %)
- Dashboard stats cards
- Dark/Light mode
- LocalStorage persistence

## Run locally
Just open `index.html` in your browser.

