/* ==========================================================================
  Student Productivity Hub (Vanilla JS)
  - Tasks: add/edit/delete/complete + filters
  - Pomodoro: start/pause/reset + settings + session counter
  - CGPA: multiple subjects (credits + grade), calculates CGPA
  - Notes: save/delete
  - Goals: progress percentage + update/edit/delete
  - Dashboard: summary cards
  - Theme: dark/light toggle (persisted)
  - Storage: LocalStorage (persisted automatically)
============================================================================ */

(() => {
  "use strict";

  /* -----------------------------
    Storage + State
  ------------------------------ */

  const STORAGE_KEY = "student_productivity_hub_v1";

  /** @returns {string} */
  const uid = () => `${Date.now()}_${Math.random().toString(16).slice(2)}`;

  const defaultState = () => ({
    settings: {
      theme: "dark",
    },
    ui: {
      view: "dashboard",
      taskFilter: "all",
    },
    tasks: [],
    notes: [],
    goals: [],
    cgpa: {
      subjects: [
        { id: uid(), name: "Subject 1", credits: 3, grade: "A" },
        { id: uid(), name: "Subject 2", credits: 4, grade: "B+" },
      ],
      lastCgpa: 0,
    },
    pomodoro: {
      workMin: 25,
      breakMin: 5,
      mode: "work", // "work" | "break"
      remainingSec: 25 * 60,
      isRunning: false,
      sessionsCompleted: 0,
    },
    stats: {
      // Just for dashboard history
      pomodoroTotalFocusSessions: 0,
    },
  });

  /**
   * Safely parse JSON from LocalStorage
   * @returns {ReturnType<typeof defaultState>}
   */
  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaultState();
      const parsed = JSON.parse(raw);
      // Merge for backward compatibility
      const base = defaultState();
      const merged = {
        ...base,
        ...parsed,
        settings: { ...base.settings, ...(parsed.settings || {}) },
        ui: { ...base.ui, ...(parsed.ui || {}) },
        cgpa: { ...base.cgpa, ...(parsed.cgpa || {}) },
        pomodoro: { ...base.pomodoro, ...(parsed.pomodoro || {}) },
        stats: { ...base.stats, ...(parsed.stats || {}) },
      };

      // If timer was running on a previous session, stop it (best UX + accuracy).
      merged.pomodoro.isRunning = false;
      return merged;
    } catch (e) {
      console.warn("Failed to load LocalStorage. Resetting state.", e);
      return defaultState();
    }
  }

  /** @param {ReturnType<typeof defaultState>} state */
  function saveState(state) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }

  let state = loadState();

  /* -----------------------------
    DOM Helpers
  ------------------------------ */

  /** @param {string} sel */
  const $ = (sel) => document.querySelector(sel);
  /** @param {string} sel */
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  function clamp(n, min, max) {
    return Math.max(min, Math.min(max, n));
  }

  function formatTime(totalSeconds) {
    const s = Math.max(0, Math.floor(totalSeconds));
    const mm = String(Math.floor(s / 60)).padStart(2, "0");
    const ss = String(s % 60).padStart(2, "0");
    return `${mm}:${ss}`;
  }

  function formatDateInput(dateStr) {
    if (!dateStr) return "";
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
    } catch {
      return dateStr;
    }
  }

  function escapeHtml(str) {
    return String(str)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  /* -----------------------------
    Toast
  ------------------------------ */

  let toastTimer = null;
  function toast(message) {
    const el = $("#toast");
    if (!el) return;
    el.textContent = message;
    el.classList.add("is-show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("is-show"), 2200);
  }

  /* -----------------------------
    Theme
  ------------------------------ */

  function applyTheme() {
    document.documentElement.setAttribute("data-theme", state.settings.theme);
    const icon = $("#themeIcon");
    if (icon) {
      icon.className = state.settings.theme === "dark" ? "fa-solid fa-moon" : "fa-solid fa-sun";
    }
  }

  function toggleTheme() {
    state.settings.theme = state.settings.theme === "dark" ? "light" : "dark";
    saveState(state);
    applyTheme();
    toast(`Switched to ${state.settings.theme} mode`);
  }

  /* -----------------------------
    Navigation
  ------------------------------ */

  function setView(viewName) {
    state.ui.view = viewName;
    saveState(state);

    $$(".nav__item").forEach((btn) => {
      btn.classList.toggle("is-active", btn.dataset.view === viewName);
    });
    $$(".view").forEach((view) => {
      view.classList.toggle("is-active", view.dataset.view === viewName);
    });

    // Close sidebar on mobile after navigating
    const sidebar = $("#sidebar");
    if (sidebar) sidebar.classList.remove("is-open");

    // Render-on-view (keeps UI correct even after background updates)
    renderAll();
  }

  function initNavigation() {
    $$(".nav__item").forEach((btn) => {
      btn.addEventListener("click", () => setView(btn.dataset.view));
    });
    const sidebarToggle = $("#sidebarToggle");
    const sidebar = $("#sidebar");
    if (sidebarToggle && sidebar) {
      sidebarToggle.addEventListener("click", () => sidebar.classList.toggle("is-open"));
    }
  }

  /* -----------------------------
    Dashboard
  ------------------------------ */

  function computeDashboardStats() {
    const totalTasks = state.tasks.length;
    const doneTasks = state.tasks.filter((t) => t.completed).length;
    const activeTasks = totalTasks - doneTasks;

    const notesCount = state.notes.length;
    const goalsCount = state.goals.length;
    const avgGoalProgress = computeAverageGoalProgress();

    return {
      totalTasks,
      doneTasks,
      activeTasks,
      notesCount,
      goalsCount,
      avgGoalProgress,
      lastCgpa: Number(state.cgpa.lastCgpa || 0),
      focusSessions: Number(state.stats.pomodoroTotalFocusSessions || 0),
    };
  }

  function renderDashboard() {
    const stats = computeDashboardStats();

    const cards = [
      {
        label: "Tasks (Active)",
        value: String(stats.activeTasks),
        hint: `${stats.doneTasks} completed`,
        icon: "fa-list-check",
      },
      {
        label: "Pomodoro Sessions",
        value: String(stats.focusSessions),
        hint: "Focus sessions finished",
        icon: "fa-clock",
      },
      {
        label: "CGPA (Last)",
        value: stats.lastCgpa ? stats.lastCgpa.toFixed(2) : "—",
        hint: "Based on last calculation",
        icon: "fa-calculator",
      },
      {
        label: "Notes",
        value: String(stats.notesCount),
        hint: "Saved notes",
        icon: "fa-note-sticky",
      },
      {
        label: "Goals",
        value: String(stats.goalsCount),
        hint: `Avg progress ${stats.avgGoalProgress}%`,
        icon: "fa-bullseye",
      },
      {
        label: "Completion Rate",
        value: totalRate(stats.totalTasks, stats.doneTasks),
        hint: "Completed / Total tasks",
        icon: "fa-chart-line",
      },
    ];

    const wrap = $("#dashboardCards");
    if (!wrap) return;

    wrap.innerHTML = cards
      .map(
        (c) => `
        <div class="card">
          <div class="card__top">
            <div>
              <div class="card__label">${escapeHtml(c.label)}</div>
              <div class="card__value">${escapeHtml(c.value)}</div>
              <div class="card__hint">${escapeHtml(c.hint)}</div>
            </div>
            <div class="card__icon" aria-hidden="true"><i class="fa-solid ${escapeHtml(
              c.icon
            )}"></i></div>
          </div>
        </div>
      `
      )
      .join("");
  }

  function totalRate(total, done) {
    if (!total) return "0%";
    return `${Math.round((done / total) * 100)}%`;
  }

  /* -----------------------------
    Tasks
  ------------------------------ */

  function addTask({ title, due, note }) {
    state.tasks.unshift({
      id: uid(),
      title: title.trim(),
      due: due || "",
      note: note ? note.trim() : "",
      completed: false,
      createdAt: new Date().toISOString(),
    });
    saveState(state);
    renderTasks();
    renderDashboard();
    toast("Task added");
  }

  function toggleTaskComplete(taskId) {
    const t = state.tasks.find((x) => x.id === taskId);
    if (!t) return;
    t.completed = !t.completed;
    saveState(state);
    renderTasks();
    renderDashboard();
  }

  function deleteTask(taskId) {
    state.tasks = state.tasks.filter((x) => x.id !== taskId);
    saveState(state);
    renderTasks();
    renderDashboard();
    toast("Task deleted");
  }

  function editTask(taskId) {
    const t = state.tasks.find((x) => x.id === taskId);
    if (!t) return;

    const newTitle = prompt("Edit task title:", t.title);
    if (newTitle === null) return;
    const newNote = prompt("Edit note (optional):", t.note || "");
    if (newNote === null) return;
    const newDue = prompt("Edit due date (YYYY-MM-DD, optional):", t.due || "");
    if (newDue === null) return;

    t.title = newTitle.trim() || t.title;
    t.note = (newNote || "").trim();
    t.due = (newDue || "").trim();

    saveState(state);
    renderTasks();
    renderDashboard();
    toast("Task updated");
  }

  function clearCompletedTasks() {
    const before = state.tasks.length;
    state.tasks = state.tasks.filter((t) => !t.completed);
    saveState(state);
    renderTasks();
    renderDashboard();
    const removed = before - state.tasks.length;
    toast(removed ? `Cleared ${removed} completed tasks` : "No completed tasks to clear");
  }

  function setTaskFilter(filter) {
    state.ui.taskFilter = filter;
    saveState(state);
    renderTasks();
  }

  function getFilteredTasks() {
    const f = state.ui.taskFilter;
    if (f === "active") return state.tasks.filter((t) => !t.completed);
    if (f === "done") return state.tasks.filter((t) => t.completed);
    return state.tasks;
  }

  function renderTasks() {
    const list = $("#taskList");
    if (!list) return;

    // Filter chips UI
    $$("#taskFilters .chip").forEach((chip) => {
      chip.classList.toggle("is-active", chip.dataset.filter === state.ui.taskFilter);
    });

    const tasks = getFilteredTasks();
    if (!tasks.length) {
      list.innerHTML = `<div class="muted">No tasks yet. Add one above.</div>`;
      return;
    }

    list.innerHTML = tasks
      .map((t) => {
        const due = t.due ? `Due: ${formatDateInput(t.due)}` : "";
        const note = t.note ? `Note: ${escapeHtml(t.note)}` : "";
        const meta = [due, note].filter(Boolean).join(" • ");

        return `
        <div class="item ${t.completed ? "is-done" : ""}">
          <button class="checkbox" data-action="toggle" data-id="${t.id}" aria-label="Complete task">
            <i class="fa-solid fa-check"></i>
          </button>
          <div>
            <div class="item__title">${escapeHtml(t.title)}</div>
            ${meta ? `<div class="item__meta">${meta}</div>` : `<div class="item__meta">—</div>`}
          </div>
          <div class="item__actions">
            <button class="btn btn--sm" data-action="edit" data-id="${t.id}">
              <i class="fa-solid fa-pen"></i>
            </button>
            <button class="btn btn--danger btn--sm" data-action="delete" data-id="${t.id}">
              <i class="fa-solid fa-trash"></i>
            </button>
          </div>
        </div>
      `;
      })
      .join("");

    // Event delegation (one listener)
    list.onclick = (e) => {
      const btn = e.target.closest("button");
      if (!btn) return;
      const action = btn.dataset.action;
      const id = btn.dataset.id;
      if (!action || !id) return;

      if (action === "toggle") toggleTaskComplete(id);
      if (action === "delete") deleteTask(id);
      if (action === "edit") editTask(id);
    };
  }

  function initTasks() {
    const form = $("#taskForm");
    if (form) {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const title = $("#taskTitle").value;
        const due = $("#taskDue").value;
        const note = $("#taskNote").value;
        if (!title.trim()) return;
        addTask({ title, due, note });
        form.reset();
        $("#taskTitle").focus();
      });
    }

    const clearBtn = $("#clearCompleted");
    if (clearBtn) clearBtn.addEventListener("click", clearCompletedTasks);

    const filterWrap = $("#taskFilters");
    if (filterWrap) {
      filterWrap.addEventListener("click", (e) => {
        const chip = e.target.closest(".chip");
        if (!chip) return;
        setTaskFilter(chip.dataset.filter);
      });
    }
  }

  /* -----------------------------
    Pomodoro
  ------------------------------ */

  let pomoInterval = null;

  function pomoStopInterval() {
    if (pomoInterval) clearInterval(pomoInterval);
    pomoInterval = null;
  }

  function pomoSetRemainingFromMode() {
    state.pomodoro.remainingSec =
      (state.pomodoro.mode === "work" ? state.pomodoro.workMin : state.pomodoro.breakMin) * 60;
  }

  function pomoSwitchMode() {
    if (state.pomodoro.mode === "work") {
      state.pomodoro.mode = "break";
      state.pomodoro.sessionsCompleted += 1;
      state.stats.pomodoroTotalFocusSessions += 1;
      toast("Focus done! Take a short break.");
    } else {
      state.pomodoro.mode = "work";
      toast("Break over! Back to focus.");
    }
    pomoSetRemainingFromMode();
    saveState(state);
    renderPomodoro();
    renderDashboard();
  }

  function pomoTick() {
    state.pomodoro.remainingSec -= 1;
    if (state.pomodoro.remainingSec <= 0) {
      pomoSwitchMode();
      return;
    }
    saveState(state);
    renderPomodoro();
  }

  function pomoStart() {
    if (state.pomodoro.isRunning) return;
    state.pomodoro.isRunning = true;
    saveState(state);
    renderPomodoro();
    pomoStopInterval();
    pomoInterval = setInterval(pomoTick, 1000);
    toast("Timer started");
  }

  function pomoPause() {
    if (!state.pomodoro.isRunning) return;
    state.pomodoro.isRunning = false;
    saveState(state);
    renderPomodoro();
    pomoStopInterval();
    toast("Paused");
  }

  function pomoReset() {
    state.pomodoro.isRunning = false;
    state.pomodoro.mode = "work";
    state.pomodoro.sessionsCompleted = 0;
    pomoSetRemainingFromMode();
    saveState(state);
    renderPomodoro();
    renderDashboard();
    pomoStopInterval();
    toast("Timer reset");
  }

  function renderPomodoro() {
    const timeEl = $("#pomoTime");
    const modeEl = $("#pomoModeLabel");
    const sessionsEl = $("#pomoSessions");
    const startBtn = $("#pomoStart");
    const pauseBtn = $("#pomoPause");

    if (timeEl) timeEl.textContent = formatTime(state.pomodoro.remainingSec);
    if (sessionsEl) sessionsEl.textContent = String(state.pomodoro.sessionsCompleted);
    if (modeEl) modeEl.textContent = state.pomodoro.mode === "work" ? "Focus" : "Break";

    if (startBtn) startBtn.disabled = state.pomodoro.isRunning;
    if (pauseBtn) pauseBtn.disabled = !state.pomodoro.isRunning;

    // Settings inputs
    const workInput = $("#pomoWork");
    const breakInput = $("#pomoBreak");
    if (workInput) workInput.value = String(state.pomodoro.workMin);
    if (breakInput) breakInput.value = String(state.pomodoro.breakMin);
  }

  function initPomodoro() {
    const startBtn = $("#pomoStart");
    const pauseBtn = $("#pomoPause");
    const resetBtn = $("#pomoReset");
    const settingsForm = $("#pomoSettingsForm");

    if (startBtn) startBtn.addEventListener("click", pomoStart);
    if (pauseBtn) pauseBtn.addEventListener("click", pomoPause);
    if (resetBtn) resetBtn.addEventListener("click", pomoReset);

    if (settingsForm) {
      settingsForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const workMin = clamp(Number($("#pomoWork").value || 25), 10, 90);
        const breakMin = clamp(Number($("#pomoBreak").value || 5), 3, 30);
        state.pomodoro.workMin = workMin;
        state.pomodoro.breakMin = breakMin;
        if (!state.pomodoro.isRunning) {
          // Keep UX simple: apply new duration immediately only when stopped.
          state.pomodoro.mode = "work";
          pomoSetRemainingFromMode();
        }
        saveState(state);
        renderPomodoro();
        toast("Timer settings saved");
      });
    }
  }

  /* -----------------------------
    CGPA
  ------------------------------ */

  const gradePoints = {
    O: 10,
    "A+": 9,
    A: 8,
    "B+": 7,
    B: 6,
    C: 5,
    P: 4,
    F: 0,
  };

  function renderCgpa() {
    const tbody = $("#cgpaTbody");
    if (!tbody) return;

    tbody.innerHTML = state.cgpa.subjects
      .map(
        (s) => `
        <tr data-id="${s.id}">
          <td>
            <input class="cgpa-name" value="${escapeHtml(s.name || "")}" placeholder="Subject" />
          </td>
          <td>
            <input class="cgpa-credits" type="number" min="0" step="1" value="${Number(
              s.credits || 0
            )}" />
          </td>
          <td>
            <select class="cgpa-grade">
              ${Object.keys(gradePoints)
                .map(
                  (g) =>
                    `<option value="${g}" ${g === s.grade ? "selected" : ""}>${g} (${gradePoints[g]})</option>`
                )
                .join("")}
            </select>
          </td>
          <td>
            <button class="btn btn--danger btn--sm" data-action="remove-subject">
              <i class="fa-solid fa-xmark"></i>
            </button>
          </td>
        </tr>
      `
      )
      .join("");

    const valueEl = $("#cgpaValue");
    if (valueEl) valueEl.textContent = (state.cgpa.lastCgpa || 0).toFixed(2);

    // Persist edits live
    tbody.oninput = (e) => {
      const tr = e.target.closest("tr");
      if (!tr) return;
      const id = tr.dataset.id;
      const subj = state.cgpa.subjects.find((x) => x.id === id);
      if (!subj) return;

      const name = tr.querySelector(".cgpa-name").value;
      const credits = Number(tr.querySelector(".cgpa-credits").value || 0);
      const grade = tr.querySelector(".cgpa-grade").value;

      subj.name = name;
      subj.credits = credits;
      subj.grade = grade;
      saveState(state);
    };

    tbody.onclick = (e) => {
      const btn = e.target.closest("button");
      if (!btn) return;
      if (btn.dataset.action !== "remove-subject") return;
      const tr = btn.closest("tr");
      if (!tr) return;
      const id = tr.dataset.id;
      state.cgpa.subjects = state.cgpa.subjects.filter((x) => x.id !== id);
      saveState(state);
      renderCgpa();
      renderDashboard();
    };
  }

  function calcCgpa() {
    let totalCredits = 0;
    let weightedSum = 0;

    for (const s of state.cgpa.subjects) {
      const credits = Number(s.credits || 0);
      const gp = gradePoints[s.grade] ?? 0;
      if (credits <= 0) continue;
      totalCredits += credits;
      weightedSum += gp * credits;
    }

    const cgpa = totalCredits ? weightedSum / totalCredits : 0;
    state.cgpa.lastCgpa = cgpa;
    saveState(state);
    renderCgpa();
    renderDashboard();
    toast("CGPA calculated");
  }

  function addSubjectRow() {
    state.cgpa.subjects.push({ id: uid(), name: "", credits: 0, grade: "A" });
    saveState(state);
    renderCgpa();
  }

  function resetCgpa() {
    if (!confirm("Reset CGPA subjects and value?")) return;
    state.cgpa.subjects = [{ id: uid(), name: "", credits: 0, grade: "A" }];
    state.cgpa.lastCgpa = 0;
    saveState(state);
    renderCgpa();
    renderDashboard();
    toast("CGPA reset");
  }

  function initCgpa() {
    const addBtn = $("#addSubject");
    const calcBtn = $("#calcCgpa");
    const resetBtn = $("#resetCgpa");
    if (addBtn) addBtn.addEventListener("click", addSubjectRow);
    if (calcBtn) calcBtn.addEventListener("click", calcCgpa);
    if (resetBtn) resetBtn.addEventListener("click", resetCgpa);
  }

  /* -----------------------------
    Notes
  ------------------------------ */

  function addNote({ title, body }) {
    state.notes.unshift({
      id: uid(),
      title: title.trim(),
      body: body.trim(),
      createdAt: new Date().toISOString(),
    });
    saveState(state);
    renderNotes();
    renderDashboard();
    toast("Note saved");
  }

  function deleteNote(noteId) {
    state.notes = state.notes.filter((n) => n.id !== noteId);
    saveState(state);
    renderNotes();
    renderDashboard();
    toast("Note deleted");
  }

  function renderNotes() {
    const grid = $("#notesGrid");
    if (!grid) return;
    if (!state.notes.length) {
      grid.innerHTML = `<div class="muted">No notes yet. Write one above.</div>`;
      return;
    }

    grid.innerHTML = state.notes
      .map((n) => {
        const dt = new Date(n.createdAt);
        const stamp = isNaN(dt.getTime())
          ? ""
          : dt.toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric" });
        return `
        <div class="note">
          <div class="note__title">${escapeHtml(n.title)}</div>
          <div class="note__meta">
            <span>${escapeHtml(stamp)}</span>
            <span>${Math.max(1, Math.ceil(n.body.length / 200))} min read</span>
          </div>
          <div class="note__body">${escapeHtml(n.body)}</div>
          <div class="note__actions">
            <button class="btn btn--danger btn--sm" data-action="delete-note" data-id="${n.id}">
              <i class="fa-solid fa-trash"></i> Delete
            </button>
          </div>
        </div>
      `;
      })
      .join("");

    grid.onclick = (e) => {
      const btn = e.target.closest("button");
      if (!btn) return;
      if (btn.dataset.action !== "delete-note") return;
      deleteNote(btn.dataset.id);
    };
  }

  function initNotes() {
    const form = $("#noteForm");
    if (form) {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const title = $("#noteTitle").value;
        const body = $("#noteBody").value;
        if (!title.trim() || !body.trim()) return;
        addNote({ title, body });
        form.reset();
        $("#noteTitle").focus();
      });
    }
  }

  /* -----------------------------
    Goals
  ------------------------------ */

  function computeGoalProgress(goal) {
    const target = Math.max(0, Number(goal.target || 0));
    const current = Math.max(0, Number(goal.current || 0));
    if (!target) return 0;
    return clamp(Math.round((current / target) * 100), 0, 100);
  }

  function computeAverageGoalProgress() {
    if (!state.goals.length) return 0;
    const sum = state.goals.reduce((acc, g) => acc + computeGoalProgress(g), 0);
    return Math.round(sum / state.goals.length);
  }

  function addGoal({ title, target, current }) {
    state.goals.unshift({
      id: uid(),
      title: title.trim(),
      target: Number(target),
      current: Number(current),
      createdAt: new Date().toISOString(),
    });
    saveState(state);
    renderGoals();
    renderDashboard();
    toast("Goal added");
  }

  function deleteGoal(goalId) {
    state.goals = state.goals.filter((g) => g.id !== goalId);
    saveState(state);
    renderGoals();
    renderDashboard();
    toast("Goal deleted");
  }

  function editGoal(goalId) {
    const g = state.goals.find((x) => x.id === goalId);
    if (!g) return;
    const t = prompt("Edit goal title:", g.title);
    if (t === null) return;
    const target = prompt("Edit target number:", String(g.target));
    if (target === null) return;
    const current = prompt("Edit current number:", String(g.current));
    if (current === null) return;

    const newTarget = Math.max(0, Number(target));
    const newCurrent = Math.max(0, Number(current));
    g.title = (t || "").trim() || g.title;
    g.target = Number.isFinite(newTarget) ? newTarget : g.target;
    g.current = Number.isFinite(newCurrent) ? newCurrent : g.current;

    saveState(state);
    renderGoals();
    renderDashboard();
    toast("Goal updated");
  }

  function updateGoalCurrent(goalId, newCurrent) {
    const g = state.goals.find((x) => x.id === goalId);
    if (!g) return;
    g.current = Math.max(0, Number(newCurrent || 0));
    saveState(state);
    renderGoals();
    renderDashboard();
  }

  function renderGoals() {
    const list = $("#goalList");
    const avg = $("#avgGoalProgress");
    if (avg) avg.textContent = `Average progress: ${computeAverageGoalProgress()}%`;
    if (!list) return;

    if (!state.goals.length) {
      list.innerHTML = `<div class="muted">No goals yet. Add one above.</div>`;
      return;
    }

    list.innerHTML = state.goals
      .map((g) => {
        const pct = computeGoalProgress(g);
        const hint = `${Number(g.current || 0)} / ${Number(g.target || 0)} (${pct}%)`;
        return `
        <div class="item">
          <div class="card__icon" aria-hidden="true"><i class="fa-solid fa-bullseye"></i></div>
          <div>
            <div class="item__title">${escapeHtml(g.title)}</div>
            <div class="item__meta">${escapeHtml(hint)}</div>
            <div class="progress" aria-label="Goal progress">
              <div class="progress__bar" style="width: ${pct}%"></div>
            </div>
            <div class="row" style="margin-top: 10px">
              <label class="muted" for="goalCurrent_${g.id}">Update current</label>
              <input
                id="goalCurrent_${g.id}"
                type="number"
                min="0"
                step="1"
                value="${Number(g.current || 0)}"
                data-action="update-current"
                data-id="${g.id}"
                style="max-width: 160px"
              />
            </div>
          </div>
          <div class="item__actions">
            <button class="btn btn--sm" data-action="edit-goal" data-id="${g.id}">
              <i class="fa-solid fa-pen"></i>
            </button>
            <button class="btn btn--danger btn--sm" data-action="delete-goal" data-id="${g.id}">
              <i class="fa-solid fa-trash"></i>
            </button>
          </div>
        </div>
      `;
      })
      .join("");

    list.oninput = (e) => {
      const input = e.target.closest("input");
      if (!input) return;
      if (input.dataset.action !== "update-current") return;
      updateGoalCurrent(input.dataset.id, input.value);
    };

    list.onclick = (e) => {
      const btn = e.target.closest("button");
      if (!btn) return;
      const action = btn.dataset.action;
      const id = btn.dataset.id;
      if (!action || !id) return;
      if (action === "delete-goal") deleteGoal(id);
      if (action === "edit-goal") editGoal(id);
    };
  }

  function initGoals() {
    const form = $("#goalForm");
    if (form) {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const title = $("#goalTitle").value;
        const target = Number($("#goalTarget").value);
        const current = Number($("#goalCurrent").value);
        if (!title.trim() || !Number.isFinite(target)) return;
        addGoal({ title, target, current: Number.isFinite(current) ? current : 0 });
        form.reset();
        $("#goalTitle").focus();
      });
    }
  }

  /* -----------------------------
    Quick actions (Dashboard)
  ------------------------------ */

  function initQuickActions() {
    const qaAddTask = $("#qaAddTask");
    const qaStartPomodoro = $("#qaStartPomodoro");
    const qaNewNote = $("#qaNewNote");

    if (qaAddTask) {
      qaAddTask.addEventListener("click", () => {
        setView("tasks");
        setTimeout(() => $("#taskTitle")?.focus(), 50);
      });
    }

    if (qaStartPomodoro) {
      qaStartPomodoro.addEventListener("click", () => {
        setView("pomodoro");
        setTimeout(() => pomoStart(), 80);
      });
    }

    if (qaNewNote) {
      qaNewNote.addEventListener("click", () => {
        setView("notes");
        setTimeout(() => $("#noteTitle")?.focus(), 50);
      });
    }
  }

  /* -----------------------------
    Render all
  ------------------------------ */

  function renderAll() {
    applyTheme();
    renderDashboard();
    renderTasks();
    renderPomodoro();
    renderCgpa();
    renderNotes();
    renderGoals();
  }

  /* -----------------------------
    Init
  ------------------------------ */

  function init() {
    applyTheme();
    initNavigation();
    initTasks();
    initPomodoro();
    initCgpa();
    initNotes();
    initGoals();
    initQuickActions();

    // Theme toggle
    const themeToggle = $("#themeToggle");
    if (themeToggle) themeToggle.addEventListener("click", toggleTheme);

    // Start on persisted view
    setView(state.ui.view || "dashboard");

    // Initial render (setView calls renderAll)
    renderAll();

    // Safety: stop timer when leaving page
    window.addEventListener("beforeunload", () => {
      state.pomodoro.isRunning = false;
      saveState(state);
      pomoStopInterval();
    });
  }

  document.addEventListener("DOMContentLoaded", init);
})();

